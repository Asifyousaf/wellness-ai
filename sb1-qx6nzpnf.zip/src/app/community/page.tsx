import { CommunityPage } from '@/components/pages/CommunityPage';

export default function Community() {
  return <CommunityPage />;
}