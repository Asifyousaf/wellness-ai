import { AIPlannerPage } from '@/components/pages/AIPlannerPage';

export default function AIPlanner() {
  return <AIPlannerPage />;
}