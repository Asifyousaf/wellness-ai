import { NutritionPage } from '@/components/pages/NutritionPage';

export default function Nutrition() {
  return <NutritionPage />;
}