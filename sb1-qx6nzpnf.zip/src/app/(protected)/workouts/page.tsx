import { WorkoutsPage } from '@/components/pages/WorkoutsPage';

export default function Workouts() {
  return <WorkoutsPage />;
}