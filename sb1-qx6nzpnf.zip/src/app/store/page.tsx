import { StorePage } from '@/components/pages/StorePage';

export default function Store() {
  return <StorePage />;
}